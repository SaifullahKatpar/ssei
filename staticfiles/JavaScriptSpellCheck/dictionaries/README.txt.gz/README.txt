Installation of New Dictionaries:

1 - Dictionaries can be downloaded for free from www.javascriptspellcheck.com/download
2 - Unzip 
3 - Copy the .dic file to this folder /JavaScriptSpellCheck/dictionaries/

Adding New Words:
1 - Add 1 word per line to JavaScriptSpellCheck/dictionaries/custom.txt

Removing Words:
1 - Add 1 word per line to JavaScriptSpellCheck/dictionaries/language-rules/banned-words.txt


Happy Coding